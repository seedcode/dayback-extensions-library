//DayBack Meetings API integration custom action v5.0
// License: MIT

//Purpose:
//Communicates with the DayBack Meetings API to Create/Delete/Reschedule a meeting

//This code is designed to be used for all custom and event actions required for
//connecting with screen-share meeting services.
//The same code will be used for each action. For each action, be sure to
//specify the "meetingType" and "action" values in the config variable just below.

//Action Type: On Event Delete Custom Action
//Open in new window: No

//More info on custom event actions here:
//https://docs.dayback.com/article/20-event-actions

Initialize(editEvent, location, innerWidth, innerHeight);

//Set Config and initialize call to Meetings API
function Initialize(editEvent, location, innerWidth, innerHeight) {
  var config = {
    //Specify the meeting type you'd like to interact with here
    //Valid values are: zoom
    meetingType: 'zoom',
    //Specify the action you'd like to take here
    //Valid values are: create, delete, eventdelete, update, start, deauthorize
    action: 'eventdelete',
    meetingsServiceURL: 'https://meetings.dayback.com'
  };
  //----------- You shouldn’t need to edit below this line -------------------

  SubmitMeetingsAPICall(config, editEvent, changesObject, location, innerWidth, innerHeight, screenY, screenX);


  function SubmitMeetingsAPICall(config, editEvent, changesObject, location, windowWidth, windowHeight, windowTop, windowLeft) {
    'use strict';
    var oAuthConfig;
    var oAuthTimeout;
    var processingNotificationDiv;
    var processingNotificationStyle = {
      'height': 'auto',
      'width': '400px',
      'margin-top': '20%'
    };
    var processingNotificationContentStyle = {
      'background': 'rgba(0,0,0,0.75)',
      'color': 'white'
    };
    var sendData = {
      version: 5.0,
      meetingType: config.meetingType,
      redirectURI: location.origin + '/',
      innerWidth: windowWidth,
      innerHeight: windowHeight,
      editEvent: editEvent,
      changesObject: changesObject
    };

    Process(config.action);
    
    

    //Authorize DayBack to connect to the API
    function AuthorizeAPI(callback) {
      var authWindow;
      var authWindowTop = oAuthConfig.authWindowInit.style.top;
      var authWindowLeft = oAuthConfig.authWindowInit.style.left;

      authWindowTop = (parseFloat(authWindowTop.substring(0, authWindowTop.length - 2)) + screenY) + 'px';
      authWindowLeft = (parseFloat(authWindowLeft.substring(0, authWindowLeft.length - 2)) + screenX) + 'px';
      
      authWindow = open(oAuthConfig.authWindowInit.src, '_blank', 
      'height=' + oAuthConfig.authWindowInit.style.height + 
      ',width=' + oAuthConfig.authWindowInit.style.width +  
      ',top=' + authWindowTop +  
      ',left=' + authWindowLeft + 
      ',toolbar=no,status=no,menubar=no');

      //Start checking for OAuth Result Code
      setTimeout(function() {
        CheckOAuthResult(authWindow, true, true, callback);
      }, 250);
    }

    function ClearOAuth(authWindow) {
      clearTimeout(oAuthTimeout);
      authWindow.close();
    }

    //Check for the OAuth code result
    function CheckOAuthResult(authWindow, recheck, waitForSignin, callback) {
      try {

        //User closed auth window. Assume this process has been cancelled
        if (authWindow.window === null){
          ClearOAuth(authWindow);
          recheck = false;
          return;
        }

        var authWindowParams = authWindow.window.location.search;

        var authRegexMatch = authWindowParams.match(new RegExp(oAuthConfig.redirectAuthRegex));
        if (authRegexMatch) {
          recheck = false;
          ClearOAuth(authWindow);

          //Set authorization code and post to take action
          sendData.authCode = authRegexMatch[oAuthConfig.redirectAuthIndex];
          console.log(sendData.authCode);
          Process(callback);
        }
      } catch (e) {
        if (!waitForSignin) {
          //Update temporary OAuth HTML objects with their display style
          Object.assign(authWindow.style, oAuthConfig.authWindowDisplay);
          waitForSignin = true;
        }
      } finally {
        if (recheck) {
          oAuthTimeout = setTimeout(function() {
            CheckOAuthResult(authWindow, recheck, waitForSignin, callback);
          }, 100);
        }
      }
    }

    function Process(action) {
      var payload;
      var modal;
      var continueFunction = Process;

      //Show notification that the API request is processing
      if(action != 'update' && action != 'eventdelete'){
        showProcessingNotification();
      }
      
      postToRelay(action, sendData, function(data) {
        //Process response if returns success

        //Clear auth code from sendData
        delete sendData.authCode;
        
        if (data.payload) {
          payload = data.payload;

          //Update Event details if provided
          if (payload.editEvent) {
            editEvent.titleEdit = payload.editEvent.titleEdit;
            editEvent.description = payload.editEvent.description;

            setTimeout(function() {
              updateEvent(editEvent, null);
            }, 500);
          }

          //Authorize with meeting API if action required
          if (data.status == 401 && payload.oAuthConfig) {
            oAuthConfig = payload.oAuthConfig;
            continueFunction = AuthorizeAPI;
            sendData.returnPayload = payload.returnPayload;
            if (!payload.modal) {

              continueFunction(payload.callback);
            }
          }

          //Show modal window if provided
          if (payload.modal) {
            modal = payload.modal;
            sendData.returnPayload = payload.returnPayload;

            utilities.showModal(modal.title, modal.message, modal.button1,
              modal.callback1 ? function() {
                continueFunction(modal.callback1);
              } : null,
              modal.button2,
              modal.callback2 ? function() {
                continueFunction(modal.callback2);
              } : null,
              modal.button3,
              modal.callback3 ? function() {
                continueFunction(modal.callback3);
              } : null);
          }

          //Open link if provided
          if (payload.openUrl) {
            open(payload.openUrl);
          }
        }

        //Show message if provided
        if (data.message) {
          dbk.showMessage(data.message);
        }
      });
    }


    //Function to simplify posts to the relay file
    function postToRelay(action, sendData, success) {
      var resultData;
      var xhttp = new XMLHttpRequest();
      sendData.action = action;
      xhttp.onreadystatechange = function() {
        if (xhttp.readyState == XMLHttpRequest.DONE){
          //Remove processing notification
          if (processingNotificationDiv){
            document.body.removeChild(processingNotificationDiv);
          }

          //Process returned data
          if (xhttp.status == 200 || xhttp.status == 401) {
            try {
              resultData = JSON.parse(xhttp.responseText);
            } catch (error) {
              resultData = xhttp.responseText;
            }
            finally {
              success(resultData);
            }
          }

          //Log error if the request does not return successful
          else {
            utilities.showModal('Error with request to ' + config.meetingType, (xhttp.responseText ? xhttp.responseText.toString() : '') + (xhttp.error ? xhttp.error.toString() : '') + (xhttp.message ? (': ' + xhttp.message) : ''), 'OK', null);
          }
        }
      };
      xhttp.onerror = function() {
        //Remove processing notification
        if (processingNotificationDiv){
          document.body.removeChild(processingNotificationDiv);
        }
        dbk.showMessage('Error processing request: ' + xhttp.responseText.toString());
      };
      xhttp.open('POST', config.meetingsServiceURL, true);
      xhttp.withCredentials = true;
      xhttp.setRequestHeader('Content-type', 'application/json;charset=UTF-8');
      xhttp.send(JSON.stringify(sendData));
    }

    //Function for modal window
    function showProcessingNotification(){
      if (!document.getElementById('processingNotificationDiv')){
        var headerObject = document.createElement('h4');
        var headerDiv = document.createElement('div');
        var modalContentObject = document.createElement('div');
        var modalMainDiv = document.createElement('div');
        processingNotificationDiv = document.createElement('div');
        processingNotificationDiv.className = 'modal fade in';
        processingNotificationDiv.style.display = 'block';
        modalMainDiv.className = 'modal-dialog';
        Object.assign(modalMainDiv.style, processingNotificationStyle);
        modalContentObject.className = 'modal-content';
        Object.assign(modalContentObject.style, processingNotificationContentStyle);
        headerDiv.className = 'pad-large text-center';
        headerObject.innerText = 'Processing API Request...';
        headerDiv.appendChild(headerObject);
        modalContentObject.appendChild(headerDiv);
        modalMainDiv.appendChild(modalContentObject);
        processingNotificationDiv.appendChild(modalMainDiv);
        processingNotificationDiv.id = 'processingNotificationDiv';
        document.body.appendChild(processingNotificationDiv);
      }
    }
  }
}
