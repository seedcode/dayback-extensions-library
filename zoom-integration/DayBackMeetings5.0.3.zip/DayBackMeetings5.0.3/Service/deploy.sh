now && now alias
